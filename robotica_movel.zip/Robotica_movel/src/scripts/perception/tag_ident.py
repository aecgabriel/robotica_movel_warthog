#!/usr/bin/env python

import cv2
import rospy
import os
import camera
from geometry_msgs.msg import PoseStamped
from cv2 import aruco
from std_msgs.msg import Bool


class Tag_ident():
    def __init__(self):

        self.img = camera.Camera()
        self.pub_goal = rospy.Publisher("/move_base_simple/goal", PoseStamped, queue_size=10)
        self.pub_aruco_found = rospy.Publisher("/warthog/aruco", Bool, queue_size=10)
        self.pic = False
        self.aruco_0 = 0
        self.aruco_1 = 0
        self.aruco_4 = 0
        self.start = False
        self.end = False


    def ident(self):

        gray = cv2.cvtColor(self.img.get(), cv2.COLOR_BGR2GRAY)
        aruco_dict = aruco.Dictionary_get(aruco.DICT_6X6_50)
        parameters = aruco.DetectorParameters_create()
        corners, ids, _ = aruco.detectMarkers(gray, aruco_dict, parameters=parameters)
        self.frame_markers = aruco.drawDetectedMarkers(self.img.get(), corners, ids)
        goal = PoseStamped()
        goal.header.frame_id = "odom"
        goal.pose.orientation.w = 0.2
        found_aruco = Bool()

        if ids is not None:
            if ids[0] == 0:
                self.aruco_0 += 1
                if self.aruco_0 > 10:
                    if not self.start:
                        rospy.loginfo("Aruco id = 0 found!")
                    goal.pose.position.x = -7
                    goal.pose.position.y = 4
                    self.pub_goal.publish(goal)
                    found_aruco.data = True
                    self.start = True
                    self.pub_aruco_found.publish(found_aruco)

            elif ids[0] == 1:
                self.aruco_1 += 1
                if self.aruco_1 > 10 and self.start:
                    if not self.pic:
                        rospy.loginfo("Aruco id = 1 found!")
                        cv2.imwrite(os.path.dirname(__file__)+"/img/aruco_1.png", self.img.get())
                        rospy.sleep(1)
                    goal.pose.position.x = 0
                    goal.pose.position.y = 0
                    self.pub_goal.publish(goal)
                    self.pic = True
                    

            # elif ids[0] == 4:
            #     self.aruco_4 += 1
            #     if not self.end and self.pic and self.aruco_4 > 10:
            #         rospy.loginfo("Aruco id = 4 found!")
            #         goal.pose.position.x = 0
            #         goal.pose.position.y = 0
            #         self.pub_goal.publish(goal)
            #         self.end = True

    def show_img(self):
        
        cv2.imshow("Tag ident", self.frame_markers)
        cv2.waitKey(1)


if __name__ == "__main__":

    rospy.init_node("Tag_ident_node", anonymous=True)
    tag_ident = Tag_ident()

    while not rospy.is_shutdown():
        tag_ident.ident()
        tag_ident.show_img()
    cv2.destroyAllWindows()
