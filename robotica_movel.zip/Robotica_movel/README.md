# Robotica_movel

Caminho para modificar os parâmetros do LiDar \
/opt/ros/kinetic/share/lms1xx/urdf/sick_lms1xx.urdf.xacro
