warthog
==

Common packages for the Warthog platform, including messages and robot description. These are packages relevant to all workspaces, whether simulation, desktop, or on the robot's own headless PC.
