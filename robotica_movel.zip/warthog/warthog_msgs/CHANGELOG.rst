^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package warthog_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2019-07-18)
------------------

0.1.0 (2018-04-12)
------------------

0.0.3 (2018-04-12)
------------------

0.0.2 (2017-11-09)
------------------
* [warthog_msgs] Updated messages for changes to platform.
* Contributors: Tony Baltovski

0.0.1 (2016-10-03)
------------------
* Initial commit.
* Contributors: Tony Baltovski
