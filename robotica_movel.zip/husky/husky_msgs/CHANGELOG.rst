^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package husky_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.4 (2019-08-01)
------------------

0.3.3 (2019-04-18)
------------------

0.3.2 (2019-03-25)
------------------

0.3.1 (2018-08-02)
------------------

0.3.0 (2018-04-11)
------------------
* Updated all package versions to 0.2.6.
* Fixed typo in URLs.
* Remove defunct email address
* Updated maintainers.
* Contributors: Paul Bovbel, Tony Baltovski

0.2.7 (2015-12-31)
------------------

0.2.6 (2015-07-08)
------------------

0.2.5 (2015-04-16)
------------------

0.2.4 (2015-04-13)
------------------

0.2.3 (2015-04-08)
------------------

0.2.2 (2015-03-23)
------------------
* Fix package urls
* Contributors: Paul Bovbel

0.2.1 (2015-03-23)
------------------

0.2.0 (2015-03-23)
------------------

0.0.2 (2015-01-30)
------------------
* Update description and maintainer
* Contributors: Paul Bovbel

0.0.1 (2015-01-12)
------------------
* Initial development of husky_msgs for Husky indigo release
* Contributors: Paul Bovbel
