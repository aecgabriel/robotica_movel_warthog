^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package warthog_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2019-08-02)
------------------
* Set a blank default world
* Re added world selection in gazebo launch
* Removed unnecessary laser argument in world launch
* Added C11 compiling
* [warthog_gazebo] Updated joint names.
* Initial commit.
* Contributors: Dave Niewinski, Tony Baltovski
